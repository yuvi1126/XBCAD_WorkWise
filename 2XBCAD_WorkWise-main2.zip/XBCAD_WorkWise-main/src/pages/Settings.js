import React from "react";

const SettingsPage = () => {
  return <h1>Settings Page</h1>;
};

export default SettingsPage;
